from django.shortcuts import render, redirect
from .models import UserData
from .forms import UserForm

def home(request):
    return render(request, 'base.html')

def form_page(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('display_page')
    else:
        form = UserForm()
    return render(request, 'form.html', {'form': form})

def display_page(request):
    user_data = UserData.objects.all()
    return render(request, 'display.html', {'user_data': user_data})

def api_endpoint(request):
    user_data = UserData.objects.all()
    data = [{'name': u.name, 'age': u.age, 'bio': u.bio} for u in user_data]
    return JsonResponse(data, safe=False)